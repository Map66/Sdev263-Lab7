package com.example.lesson_07_android_recycleview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.lesson_07_android_recycleview.data.Place
import com.example.lesson_07_android_recycleview.data.PlaceListAdapter

private var adapter:PlaceListAdapter?=null
private var countryList:ArrayList<Place>?=null
private var layoutManager:RecyclerView.LayoutManager?=null

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        countryList= ArrayList<Place>()
        layoutManager=LinearLayoutManager(this)
        adapter= PlaceListAdapter(countryList!!,this)

        val myRecyclerView : RecyclerView = findViewById(R.id.myRecyclerView)
        myRecyclerView.layoutManager= layoutManager
        myRecyclerView.adapter= adapter

        // load data
        var countryNameList:Array<String> = arrayOf("Canada", "USA", "Mexico", "Columbia", "Malaysia",
        "Singapore", "Turkey", "Nicaragua", "India", "Italy", "Tunisia", "Chile", "Argentina", "Spain", "Peru")
        var citiesNameList:Array<String> = arrayOf("Ottawa", "Washington D.C.", "Mexico City", "Bogota",
        "Kuala Lumpur", "Singapore", "Ankara", "Manague", "New Delhi", "Rome", "Tunis", "Satntiago",
        "Buenos Aires", "Madrid", "Lima")

        for (i in 0..14) {
            var place=Place()
            place.CountryName = countryNameList[i]
            place.CityName = citiesNameList[i]
            countryList?.add(place)
        }
        adapter!!.notifyDataSetChanged()
    }
}