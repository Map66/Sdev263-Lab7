package com.example.lesson_07_android_recycleview.data

class Place {
    var CountryName: String? = null
    var CityName: String?=null
}