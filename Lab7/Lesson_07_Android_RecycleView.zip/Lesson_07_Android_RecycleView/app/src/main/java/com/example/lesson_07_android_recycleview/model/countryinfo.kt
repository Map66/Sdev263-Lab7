package com.example.lesson_07_android_recycleview.model

class countryinfo {
}